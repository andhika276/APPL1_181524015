# <p align="center"> Courses from the main program in SoftUni <p>

<a href="https://softuni.bg/trainings/courses" rel="Courses">  ![SoftUni logo][logo] <a/>

[logo]: http://innovationstarterbox.bg/wp-content/uploads/2016/05/Softuni_logo_trasparent.png "Logo Title Text 2"

<br/>
<br/>
<br/>

<h2> Certificates </h2>

|**Course**|**Link**| 
|---|---|
|<a href="https://softuni.bg/trainings/1439/programming-basics-august-2016" > Programming Basics </a>   | <a href="https://softuni.bg/certificates/details/15409/8d5c6577"> Link</a> |
|<a href="https://softuni.bg/trainings/1568/programming-fundamentals-exended-january-2017"> Programming Fundamentals - Extended  </a>| <a href="https://softuni.bg/certificates/details/19338/71d887b2"> Link</a> |
|<a href="https://softuni.bg/trainings/1511/software-technologies-february-2017"> Software Technologies  </a> | <a href="https://softuni.bg/certificates/details/19170/7e207039"> Link</a> |
|<a href="https://softuni.bg/trainings/1633/csharp-advanced-may-2017"> C# Advanced </a> | <a href="https://softuni.bg/certificates/details/21495/56612b1f"> Link</a> |
|<a href="https://softuni.bg/trainings/1636/c-sharp-oop-basics-june-2017"> C# OOP Basics </a> | <a href="https://softuni.bg/certificates/details/21638/e39c11ae"> Link</a> |
|<a href="https://softuni.bg/courses/csharp-oop-advanced-high-quality-code"> C# OOP Advanced</a> | <a href="https://softuni.bg/certificates/details/23377/34ce688d"> Link</a> |
|<a href="https://softuni.bg/trainings/1747/databases-basics-mssql-server-september-2017/internal"> Databases Basics - MS SQL Server </a> | <a href="https://softuni.bg/certificates/details/23901/477ecc1a"> Link</a> |
|<a href="https://softuni.bg/courses/databases-advanced-entity-framework"> Databases Advanced - Entity Framework </a> | <a href="https://softuni.bg/certificates/details/49703/217cf00f"> Link</a> |
|<a href="https://softuni.bg/trainings/1850/js-fundamentals-january-2018"> JavaScript Fundamentals </a> | <a href="https://softuni.bg/certificates/details/51647/9570106f"> Link</a> |
|<a href="https://softuni.bg/courses/javascript-advanced"> JavaScript Advanced </a> | <a href="https://softuni.bg/certificates/details/53002/2f221978"> Link</a> |
|<a href="https://softuni.bg/courses/javascript-applications"> JavaScript Applications </a> | <a href="https://softuni.bg/certificates/details/54725/d2412db2"> Link</a> |