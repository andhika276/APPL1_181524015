# <a href="https://softuni.bg/trainings/1637/c-sharp-oop-advanced-july-2017" rel="OOP Advance"><p align="center"> OOP Advance <p>
</a>

---

## Exercises
- <a href="https://github.com/stefkavasileva/SoftUni-Software-Engineering/tree/master/C%23Fundamentals/OOP-Advanced/Exercises/InterfacesAndAbstraction-Lab" > Interfaces and Abstraction - Lab </a> 
- <a href="https://github.com/stefkavasileva/SoftUni-Software-Engineering/tree/master/C%23Fundamentals/OOP-Advanced/Exercises/IteratorComparator-Exercises" > Interfaces and Abstraction - Exercoses </a> 
- <a href="https://github.com/stefkavasileva/SoftUni-Software-Engineering/tree/master/C%23Fundamentals/OOP-Advanced/Exercises/Generics-Lab" > Generics - Lab </a> 
- <a href="https://github.com/stefkavasileva/SoftUni-Software-Engineering/tree/master/C%23Fundamentals/OOP-Advanced/Exercises/Generics-Exercise" > Generics - Exercises </a> 
- <a href="https://github.com/stefkavasileva/SoftUni-Software-Engineering/tree/master/C%23Fundamentals/OOP-Advanced/Exercises/IteratorsComparators-Lab" > Iterator and Comparator - Lab  </a> 
- <a href="https://github.com/stefkavasileva/SoftUni-Software-Engineering/tree/master/C%23Fundamentals/OOP-Advanced/Exercises/IteratorComparator-Exercises" > Iterator and Comparator - Exercises  </a> 
- <a href="https://github.com/stefkavasileva/SoftUni-Software-Engineering/tree/master/C%23Fundamentals/OOP-Advanced/Exercises/EnumerationsAttributes-Lab" > Enumerations and Attributes - Lab </a> 
- <a href="https://github.com/stefkavasileva/SoftUni-Software-Engineering/tree/master/C%23Fundamentals/OOP-Advanced/Exercises/EnumsAttributes-Exercise" > Enumerations and Attributes - Exercises </a> 
- <a href="https://github.com/stefkavasileva/SoftUni-Software-Engineering/tree/master/C%23Fundamentals/OOP-Advanced/Exercises/Reflection-Lab" > Reflection - Lab </a> 
- <a href="https://github.com/stefkavasileva/SoftUni-Software-Engineering/tree/master/C%23Fundamentals/OOP-Advanced/Exercises/Reflection-Exercise" > Reflection - Exercise </a>
- <a href="https://github.com/stefkavasileva/SoftUni-Software-Engineering/tree/master/C%23Fundamentals/OOP-Advanced/Exercises/UnitTesting-Lab" > UnitTesting - Lab </a>
- <a href="https://github.com/stefkavasileva/SoftUni-Software-Engineering/tree/master/C%23Fundamentals/OOP-Advanced/Exercises/UnitTesting-Exercises" > UnitTesting - Exercises </a>
- <a href="https://github.com/stefkavasileva/SoftUni-Software-Engineering/tree/master/C%23Fundamentals/OOP-Advanced/Exercises/SOLID-Lab" > SOLID - Lab </a>
- <a href="https://github.com/stefkavasileva/SoftUni-Software-Engineering/tree/master/C%23Fundamentals/OOP-Advanced/Exercises/SOLID-Exercise" > SOLID - Exercises </a>
- <a href="https://github.com/stefkavasileva/SoftUni-Software-Engineering/tree/master/C%23Fundamentals/OOP-Advanced/Exercises/ObjectAndEvents-Exercises" > Object And Events - Exercises </a>

## Exams

-  <a href="https://github.com/stefkavasileva/SoftUni-Software-Engineering/tree/master/C%23Fundamentals/OOP-Advanced/Exams/Hell-Skeleton" > HELL </a>
-  <a href="https://github.com/stefkavasileva/SoftUni-Software-Engineering/tree/master/C%23Fundamentals/OOP-Advanced/Exams/LastArmy-20.08.17" > Last Army </a>
