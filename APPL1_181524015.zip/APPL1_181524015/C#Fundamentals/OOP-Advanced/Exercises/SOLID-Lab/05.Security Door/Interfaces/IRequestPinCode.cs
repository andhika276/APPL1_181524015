﻿namespace _05.Security_Door.Interfaces
{
    public interface IRequestPinCode
    {
        int RequestPinCode();
    }
}
