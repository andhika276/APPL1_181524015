﻿namespace _02.Graphic_Editor
{
    public interface IShape
    {
        string Drow();
    }
}